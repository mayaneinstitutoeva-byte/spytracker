import { useState, useEffect } from 'react';
import { Shield, MapPin } from 'lucide-react';

interface LocationData {
  city: string;
  region: string;
  ip: string;
}

const Header = () => {
  const [location, setLocation] = useState<LocationData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchLocation = async () => {
      try {
        // ⚠️ Importante: em sites HTTPS, chamadas HTTP são bloqueadas (mixed content).
        // Por isso, trocamos o ip-api (http) por um provedor HTTPS.

        // 1) ipwho.is (HTTPS, sem key)
        const response = await fetch('https://ipwho.is/?fields=success,ip,city,region');
        const data = await response.json();

        if (data?.success && data?.city) {
          setLocation({
            city: data.city,
            region: data.region,
            ip: data.ip,
          });
          return;
        }

        throw new Error('ipwho.is returned no city');
      } catch (error) {
        console.log('Falling back to ipapi.co');
        try {
          // Fallback to ipapi.co
          const response = await fetch('https://ipapi.co/json/');
          const data = await response.json();
          
          if (data.city) {
            setLocation({
              city: data.city,
              region: data.region,
              ip: data.ip
            });
          }
        } catch (fallbackError) {
          console.error('Could not fetch location:', fallbackError);
        }
      } finally {
        setLoading(false);
      }
    };

    fetchLocation();
  }, []);

  const maskIP = (ip: string) => {
    if (!ip) return 'xxx.xxx.xxx.xxx';
    const parts = ip.split('.');
    if (parts.length === 4) {
      return `${parts[0]}.${parts[1]}.xxx.xxx`;
    }
    return ip.substring(0, ip.length / 2) + 'xxx';
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-primary/10 border border-primary/30 flex items-center justify-center">
            <Shield className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="text-xl font-bold">
              <span className="text-foreground">SPY</span>
              <span className="text-primary">TRACKER</span>
            </h1>
            <p className="text-[10px] text-primary tracking-[0.2em]">SISTEMA AVANÇADO</p>
          </div>
        </div>

        {/* Location Badge */}
        <div className="hidden sm:flex items-center gap-3 bg-card border border-border rounded-full px-4 py-2">
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-primary" />
            <div className="text-right">
              {loading ? (
                <>
                  <div className="h-4 w-24 bg-muted rounded animate-pulse mb-1" />
                  <div className="h-3 w-20 bg-muted rounded animate-pulse" />
                </>
              ) : location ? (
                <>
                  <p className="text-sm font-medium text-foreground">
                    {location.city}, {location.region}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    IP: {maskIP(location.ip)}
                  </p>
                </>
              ) : (
                <>
                  <p className="text-sm font-medium text-foreground">Localização</p>
                  <p className="text-xs text-muted-foreground">Não detectada</p>
                </>
              )}
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
            <span className="text-xs text-red-500 font-medium">LIVE</span>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
