import { useEffect, useState } from 'react';

interface ScanningAnimationProps {
  phone: string;
  onComplete: () => void;
}

const ScanningAnimation = ({ phone, onComplete }: ScanningAnimationProps) => {
  const [status, setStatus] = useState('Conectando aos servidores...');
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const statuses = [
      'Conectando aos servidores...',
      `Verificando número: +55 ${phone}`,
      'Dados encontrados!',
    ];

    const timer1 = setTimeout(() => setStatus(statuses[1]), 2000);
    const timer2 = setTimeout(() => setStatus(statuses[2]), 4000);
    const timer3 = setTimeout(() => onComplete(), 5000);

    const progressInterval = setInterval(() => {
      setProgress(prev => Math.min(prev + 2, 100));
    }, 100);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
      clearInterval(progressInterval);
    };
  }, [phone, onComplete]);

  return (
    <div className="w-full max-w-lg mx-auto text-center animate-fade-in">
      {/* Scanner circles */}
      <div className="relative w-64 h-64 mx-auto mb-8">
        {/* Rotating ring */}
        <div className="absolute inset-0 border-2 border-primary/20 rounded-full" />
        <div 
          className="absolute inset-0 border-2 border-transparent border-t-primary rounded-full animate-spin-slow"
          style={{ animationDuration: '3s' }}
        />
        
        {/* Pulse rings */}
        <div className="absolute inset-4 border border-primary/30 rounded-full animate-pulse" />
        <div className="absolute inset-8 border border-primary/40 rounded-full animate-pulse" style={{ animationDelay: '0.5s' }} />
        <div className="absolute inset-12 border border-primary/50 rounded-full animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute inset-16 border border-primary/60 rounded-full animate-pulse" style={{ animationDelay: '1.5s' }} />

        {/* Center content */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center">
            <p className="text-primary font-medium tracking-widest text-sm animate-pulse">SCANNING...</p>
          </div>
        </div>

        {/* Scanning line */}
        <div className="absolute inset-0 overflow-hidden rounded-full">
          <div 
            className="absolute inset-x-0 h-1 bg-gradient-to-b from-transparent via-primary to-transparent animate-scan-line"
            style={{ animationDuration: '2s' }}
          />
        </div>
      </div>

      {/* Status text */}
      <div className="space-y-2">
        <p className="text-foreground">{status}</p>
        {status.includes('Verificando') && (
          <p className="text-primary font-medium">+55 {phone}</p>
        )}
        {status === 'Dados encontrados!' && (
          <p className="text-primary font-bold animate-pulse">Dados encontrados!</p>
        )}
      </div>

      {/* Progress bar */}
      <div className="mt-6 w-full max-w-xs mx-auto">
        <div className="h-1 bg-border rounded-full overflow-hidden">
          <div 
            className="h-full bg-primary transition-all duration-100 rounded-full"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
    </div>
  );
};

export default ScanningAnimation;
