import { useState } from 'react';
import { Smartphone, Search, Wifi, Lock, Shield } from 'lucide-react';

interface TrackerFormProps {
  onTrack: (phone: string) => void;
  isTracking: boolean;
}

const TrackerForm = ({ onTrack, isTracking }: TrackerFormProps) => {
  const [phone, setPhone] = useState('');

  const formatPhone = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 2) return numbers;
    if (numbers.length <= 7) return `(${numbers.slice(0, 2)}) ${numbers.slice(2)}`;
    return `(${numbers.slice(0, 2)}) ${numbers.slice(2, 7)}-${numbers.slice(7, 11)}`;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatPhone(e.target.value);
    setPhone(formatted);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (phone.replace(/\D/g, '').length >= 10) {
      onTrack(phone);
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto animate-fade-in">
      {/* Status badges */}
      <div className="flex items-center justify-center gap-6 mb-8 flex-wrap">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <span className="w-2 h-2 bg-primary rounded-full status-online" />
          Sistema Online
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Wifi className="w-4 h-4 text-primary" />
          Conexão Segura
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Lock className="w-4 h-4 text-muted-foreground" />
          Criptografado
        </div>
      </div>

      {/* Title */}
      <h2 className="text-3xl sm:text-4xl font-bold text-center mb-4">
        <span className="text-foreground">Rastreie qualquer </span>
        <span className="text-primary">WhatsApp</span>
      </h2>
      <p className="text-muted-foreground text-center mb-8">
        Insira o número do celular para acessar mensagens, fotos e localização
      </p>

      {/* Form Card */}
      <div className="glass-card p-6 glow-border">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-lg bg-primary/10 border border-primary/30 flex items-center justify-center">
            <Smartphone className="w-5 h-5 text-primary" />
          </div>
          <div>
            <p className="font-medium text-foreground">Número do WhatsApp</p>
            <p className="text-sm text-muted-foreground">Brasil (+55)</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1 flex items-center bg-input border border-border rounded-lg overflow-hidden focus-within:border-primary focus-within:ring-1 focus-within:ring-primary transition-all">
            <span className="px-4 py-4 text-primary font-medium border-r border-border">+55</span>
            <input
              type="tel"
              value={phone}
              onChange={handleChange}
              placeholder="(00) 00000-0000"
              className="flex-1 px-4 py-4 bg-transparent text-foreground placeholder:text-muted-foreground focus:outline-none text-lg"
              disabled={isTracking}
            />
          </div>
          <button
            type="submit"
            disabled={isTracking || phone.replace(/\D/g, '').length < 10}
            className="px-8 py-4 bg-primary text-primary-foreground font-semibold rounded-lg btn-primary disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 min-w-[140px]"
          >
            <Search className="w-5 h-5" />
            Rastrear
          </button>
        </form>

        {/* Features */}
        <div className="flex items-center justify-center gap-6 mt-6 flex-wrap">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span className="w-1.5 h-1.5 bg-primary rounded-full" />
            100% Anônimo
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span className="w-1.5 h-1.5 bg-primary rounded-full" />
            Sem Instalação
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span className="w-1.5 h-1.5 bg-primary rounded-full" />
            Indetectável
          </div>
        </div>
      </div>
    </div>
  );
};

export default TrackerForm;
