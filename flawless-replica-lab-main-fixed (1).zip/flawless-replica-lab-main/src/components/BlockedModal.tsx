import { X, Lock, Check, Zap, CreditCard } from 'lucide-react';

interface BlockedModalProps {
  onClose: () => void;
}

const BlockedModal = ({ onClose }: BlockedModalProps) => {
  const features = [
    'Acesso a todas as mensagens',
    'Fotos e vídeos em alta resolução',
    'Localização em tempo real 24/7',
    'Monitoramento invisível',
    'Histórico completo de 90 dias',
    '100% Anônimo e seguro',
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-background/80 backdrop-blur-sm"
        onClick={onClose}
      />
      
      {/* Modal */}
      <div className="relative w-full max-w-md bg-card border border-border rounded-2xl shadow-2xl animate-fade-in overflow-hidden">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-secondary flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors z-10"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Lock icon */}
        <div className="flex justify-center pt-8">
          <div className="w-16 h-16 rounded-2xl bg-primary flex items-center justify-center shadow-glow-lg">
            <Lock className="w-8 h-8 text-primary-foreground" />
          </div>
        </div>

        {/* Content */}
        <div className="p-6 text-center">
          <h2 className="text-2xl font-bold mb-2">
            <span className="text-foreground">Conteúdo </span>
            <span className="text-primary">Bloqueado</span>
          </h2>
          <p className="text-muted-foreground text-sm">
            Desbloqueie acesso total ao dispositivo alvo
          </p>
        </div>

        {/* Features grid */}
        <div className="px-6 grid grid-cols-2 gap-3">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="flex items-center gap-2 p-3 bg-secondary/50 rounded-lg border border-border"
            >
              <Check className="w-4 h-4 text-primary flex-shrink-0" />
              <span className="text-sm text-foreground">{feature}</span>
            </div>
          ))}
        </div>

        {/* Pricing */}
        <div className="p-6">
          <div className="bg-secondary/50 rounded-xl p-4 border border-border">
            <p className="text-xs text-muted-foreground tracking-widest mb-2">ACESSO VITALÍCIO</p>
            <div className="flex items-baseline gap-2">
              <span className="text-muted-foreground line-through text-lg">R$ 97,90</span>
              <span className="text-4xl font-bold text-foreground">R$ 29,90</span>
              <span className="px-2 py-1 bg-red-500 text-white text-xs font-bold rounded">-69% OFF</span>
            </div>
            <div className="flex items-center gap-2 mt-3 text-amber-400">
              <Zap className="w-4 h-4" />
              <span className="text-sm font-medium">Oferta por tempo limitado! Restam 3 vagas</span>
            </div>
          </div>
        </div>

        {/* CTA Button */}
        <div className="px-6 pb-6">
          <button className="w-full py-4 bg-primary text-primary-foreground font-bold rounded-xl btn-primary flex items-center justify-center gap-2 text-lg">
            <CreditCard className="w-5 h-5" />
            Desbloquear Agora
          </button>
        </div>
      </div>
    </div>
  );
};

export default BlockedModal;
