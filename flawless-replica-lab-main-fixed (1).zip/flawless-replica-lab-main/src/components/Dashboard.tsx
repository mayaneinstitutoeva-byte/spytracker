import { useState } from 'react';
import { MessageCircle, Image, MapPin, Phone, Users, History, Lock, ChevronRight } from 'lucide-react';
import BlockedModal from './BlockedModal';

interface DashboardProps {
  phone: string;
}

interface Message {
  id: number;
  name: string;
  initial: string;
  color: string;
  time: string;
  hasMedia?: boolean;
}

const Dashboard = ({ phone }: DashboardProps) => {
  const [showModal, setShowModal] = useState(false);

  const menuItems = [
    { icon: MessageCircle, label: 'WhatsApp', sublabel: 'Mensagens e co...', count: '847', color: 'bg-primary', active: true },
    { icon: Image, label: 'Galeria', sublabel: 'Fotos e vídeos', count: '2.4k', color: 'bg-pink-500' },
    { icon: MapPin, label: 'Localização', sublabel: 'GPS em tempo ...', badge: 'LIVE', color: 'bg-red-500' },
    { icon: Phone, label: 'Chamadas', sublabel: 'Histórico de liga...', count: '156', color: 'bg-blue-500' },
    { icon: Users, label: 'Contatos', sublabel: 'Lista de contatos', count: '312', color: 'bg-orange-500' },
    { icon: History, label: 'Histórico', sublabel: 'Navegação web', count: '1.2k', color: 'bg-muted-foreground' },
  ];

  const messages: Message[] = [
    { id: 1, name: 'Maria Silva', initial: 'M', color: 'bg-primary', time: '14:32', hasMedia: true },
    { id: 2, name: 'João Trabalho', initial: 'J', color: 'bg-amber-600', time: '13:45' },
    { id: 3, name: 'Mãe ❤️', initial: 'M', color: 'bg-primary', time: '12:20', hasMedia: true },
    { id: 4, name: 'Pedro Gym', initial: 'P', color: 'bg-purple-500', time: '11:15' },
    { id: 5, name: 'Grupo Família', initial: 'G', color: 'bg-primary', time: '10:00', hasMedia: true },
    { id: 6, name: 'Banco Notificações', initial: 'B', color: 'bg-blue-500', time: '09:30' },
  ];

  return (
    <div className="min-h-screen bg-background pt-20 animate-fade-in">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Sidebar */}
          <div className="lg:w-80">
            <div className="glass-card p-6 glow-border">
              {/* Target info */}
              <div className="mb-6">
                <p className="text-xs text-muted-foreground tracking-widest mb-1">ALVO IDENTIFICADO</p>
                <p className="text-2xl font-bold text-primary">+55 {phone}</p>
                <div className="flex items-center gap-2 mt-2">
                  <span className="w-2 h-2 bg-primary rounded-full status-online" />
                  <span className="text-sm text-primary">Online agora</span>
                </div>
              </div>

              {/* Menu items */}
              <nav className="space-y-2">
                {menuItems.map((item, index) => (
                  <button
                    key={index}
                    onClick={() => setShowModal(true)}
                    className={`w-full flex items-center gap-3 p-3 rounded-lg transition-all ${
                      item.active 
                        ? 'bg-primary/10 border border-primary/30' 
                        : 'hover:bg-secondary border border-transparent'
                    }`}
                  >
                    <div className={`w-10 h-10 rounded-lg ${item.color} flex items-center justify-center`}>
                      <item.icon className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1 text-left">
                      <p className="font-medium text-foreground">{item.label}</p>
                      <p className="text-xs text-muted-foreground">{item.sublabel}</p>
                    </div>
                    {item.count && (
                      <span className="px-2 py-1 bg-secondary rounded text-xs text-muted-foreground">{item.count}</span>
                    )}
                    {item.badge && (
                      <span className="px-2 py-1 bg-red-500/20 text-red-500 rounded text-xs font-medium">{item.badge}</span>
                    )}
                    <Lock className="w-4 h-4 text-muted-foreground" />
                  </button>
                ))}
              </nav>
            </div>
          </div>

          {/* Main content */}
          <div className="flex-1">
            <div className="glass-card p-6 glow-border">
              {/* Header */}
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <MessageCircle className="w-6 h-6 text-primary" />
                  <h2 className="text-xl font-semibold text-foreground">Conversas Recentes</h2>
                </div>
                <span className="text-primary font-medium">847 mensagens</span>
              </div>

              {/* Messages list */}
              <div className="space-y-3">
                {messages.map((message) => (
                  <button
                    key={message.id}
                    onClick={() => setShowModal(true)}
                    className="w-full flex items-center gap-4 p-4 bg-secondary/50 rounded-lg hover:bg-secondary transition-all group"
                  >
                    <div className={`w-12 h-12 rounded-full ${message.color} flex items-center justify-center text-white font-semibold text-lg`}>
                      {message.initial}
                    </div>
                    <div className="flex-1 text-left">
                      <p className="font-medium text-foreground">{message.name}</p>
                      <div className="h-4 w-48 bg-muted rounded mt-1" />
                    </div>
                    <div className="text-right flex items-center gap-3">
                      <div>
                        <p className="text-sm text-muted-foreground">{message.time}</p>
                      </div>
                      {message.hasMedia ? (
                        <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                          <Image className="w-4 h-4 text-primary" />
                        </div>
                      ) : (
                        <Lock className="w-4 h-4 text-muted-foreground" />
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {showModal && <BlockedModal onClose={() => setShowModal(false)} />}
    </div>
  );
};

export default Dashboard;
