import { useState } from 'react';
import LoginScreen from '@/components/LoginScreen';
import Header from '@/components/Header';
import TrackerForm from '@/components/TrackerForm';
import ScanningAnimation from '@/components/ScanningAnimation';
import Dashboard from '@/components/Dashboard';

type AppState = 'login' | 'home' | 'scanning' | 'dashboard';

const Index = () => {
  const [appState, setAppState] = useState<AppState>('login');
  const [phone, setPhone] = useState('');

  const handleLogin = () => {
    setAppState('home');
  };

  const handleTrack = (phoneNumber: string) => {
    setPhone(phoneNumber);
    setAppState('scanning');
  };

  const handleScanComplete = () => {
    setAppState('dashboard');
  };

  if (appState === 'login') {
    return <LoginScreen onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Background effects */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-[600px] h-[600px] bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-[600px] h-[600px] bg-primary/5 rounded-full blur-3xl" />
      </div>

      {/* Grid pattern */}
      <div 
        className="fixed inset-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage: `linear-gradient(hsl(var(--primary)) 1px, transparent 1px),
                           linear-gradient(90deg, hsl(var(--primary)) 1px, transparent 1px)`,
          backgroundSize: '60px 60px'
        }}
      />

      <Header />

      <main className="relative z-10 pt-24 pb-12 px-4">
        {appState === 'home' && (
          <div className="min-h-[calc(100vh-8rem)] flex items-center justify-center">
            <TrackerForm onTrack={handleTrack} isTracking={false} />
          </div>
        )}

        {appState === 'scanning' && (
          <div className="min-h-[calc(100vh-8rem)] flex items-center justify-center">
            <ScanningAnimation phone={phone} onComplete={handleScanComplete} />
          </div>
        )}

        {appState === 'dashboard' && <Dashboard phone={phone} />}
      </main>
    </div>
  );
};

export default Index;
